Template Name  : Settings - User Control
Compatible With: DNN 6.x, 7.x

A Settings user control which can be accessed as a tab within the Module Settings user interface

Settings.ascx
Settings.ascx.cs
Settings.ascx.resx

(Include any special instructions for this Module Template in this area)