﻿;(function($, window, document, undefined) {

	var didResize = false;
	var didInit = false;
	var $pageWrap,
		$headerWrap,
		$header,
		$pageFooter,
		$menuMain,
		$headerMainTopVal,
		$scrollVal,
		$mainNav;
	
	$(document).ready(function () {
		$pageWrap = $("#pageWrap");
		$headerWrap = $(".p-header-wrap").get(0);
		$header = $($headerWrap).find(".p-header");
		$pageFooter = $("#pageFooter");
		$menuMain = $(".p-main-menu").get(0);
		$headerMainTopVal = $($menuMain).offset().top;
		$mainNav = $(".main-menu-nav").get(0);

		if (!didInit) {
			init();
			didInit = true;
		}

	});

	$(window).resize(function () {
		didResize = true;
	});

	$(window).scroll(function() {
		stickHeader();
	});

	var resizeInterval = setInterval(function() {
		if (didResize) {
			didResize = false;
			stickFooter();
		}
	}, 250);

	// Main Init Func
	function init() {
		stickFooter();
		stickHeader();
		initDttg();
		initSelectPicker();
		expandMobileMenu();
		setPlaceholders();
		wrapPrice(".hc-record .hc-recprice");
		removeEmptyPanes(".content-wrap", ".p-content > .container", ".p-content > .content-pane");

		(Modernizr.touch) ? $("html").addClass("touchevents") : $("html").addClass("no-touchevents");

	}

	// Functions
	function stickFooter() {
		$(window).width() > 991 
			? $($pageWrap).css("margin-bottom", $($pageFooter).outerHeight(true))
			: $($pageWrap).css("margin-bottom", 0);
	}

	function stickHeader() {
		$scrollVal = $(window).scrollTop();

		if ($(window).width() > 991) {
			$scrollVal > $headerMainTopVal ? $($headerWrap).addClass("fixed-menu") : $($headerWrap).removeClass("fixed-menu");
		} else {
			if ($($headerWrap).hasClass("fixed-menu")) {
				$($headerWrap).removeClass("fixed-menu");
			} 
		}
	}

	function wrapPrice(el) {
		var $el = $(el);

		$.each($el, function () {
			var price = $(this).text();
			var point = price.indexOf(".");
			var toDot = price.slice(0, point + 1);
			var afterDot = price.slice(point + 1, price.length);
			var html = toDot + "<span>" + afterDot + "</span>";

			return $(this).html(html);
		});
	}

	function removeEmptyPanes(el) {
		if ($("body").hasClass("dnnEditState")) { return; }

		var args = Array.prototype.slice.call(arguments);

		$.each(args, function(i, val) {
			$.each($(val), function(i, val) {
				getRidOfEl(val);
			});
		});

		function getRidOfEl(el) {
			if ($(el).hasClass(".content-pane")) {
				$(el).hide();
				return;
			}

			var $panes = $(el).find(".content-pane");
			var $emptyPanes = $panes.filter(".DNNEmptyPane");

			if ($panes.length === $emptyPanes.length) {
				$(el).hide();
			}
		}
	}

	function initSelectPicker() {
		$pageWrap.find("select").selectpicker();
	}

	function initDttg() {
		$(".nav-list li:has(ul)").doubleTapToGo();
	}

	function expandMobileMenu() {
		var $button = $("#expandDropdownMenu");

		$button.on("click", function (e) {
			e.preventDefault();

			if ($header.hasClass("expanded-menu")) {
				$header.removeClass("expanded-menu");
			} else {
				$header.addClass("expanded-menu");
			}
		});
	}

	function setPlaceholders() {
		if (!Modernizr.input.placeholder) {
			$("[placeholder]").focus(function () {
				var input = $(this);
				if (input.val() === input.attr("placeholder")) {
					input.val("");
				}
			}).blur(function () {
				var input = $(this);
				if (input.val() === "" || input.val() === input.attr("placeholder")) {
					input.val(input.attr("placeholder"));
				}
			}).blur();

			$("[placeholder]").parents("form").submit(function () {
				$(this).find("[placeholder]").each(function () {
					var input = $(this);
					if (input.val() === input.attr("placeholder")) {
						input.val("");
					}
				});
			});
		}
	}

	$.fn.equalHeights = function () {
		return this.height(Math.max.apply(this, $.map(this, function(e) { return $(e).height(); })));
	}

})(jQuery, window, document);
