$(document).ready(function(e) {
	(function ($) {
		$(".has-dropdown").attr("aria-haspopup", "true");
		$(".has-dropdown.active").attr("aria-haspopup", "true");
		$(".dropdown-menu").attr("aria-haspopup", "false");
	})(jQuery);
});