Template Name  : DAL2
Compatible With: DNN 7.x

A business object class, a controller class with data access methods, and a SQL installation and uninstallation script

01.00.00.sql
templateInfo.cs
templateController.cs
uninstall.sql

*NOTE: When you add this module template there will be a momentary delay while the DNN application restarts

(Include any special instructions for this Module Template in this area)