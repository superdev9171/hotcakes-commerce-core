Template Name  : XML Document
Compatible With: DNN 6.x, 7.x

An XML file

template.xml

(Include any special instructions for this Module Template in this area)