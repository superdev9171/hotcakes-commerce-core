#region Copyright

// 
// Copyright (c) _YEAR_
// by _OWNER_
// 

#endregion

#region Using Statements

using DotNetNuke.Entities.Modules;

#endregion

namespace _OWNER_._MODULE_
{

	public class _CONTROL_
	{

	}
}
